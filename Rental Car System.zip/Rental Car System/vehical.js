const popupButton = document.querySelectorAll('.book_button');
const popupDetails = document.querySelector('.pop_up_details');
const popupOverlay = document.querySelector('.pop_up_overlay');
const bodyy = document.body;

popupButton.forEach(link => {
    link.addEventListener('click', () => {
        popupDetails.style.display = 'block';
        popupOverlay.style.display = 'block';
        bodyy.style.overflow = 'hidden';
    });
});


popupDetails.querySelector('.close_pop_up').addEventListener('click', () => {
    popupDetails.style.display = 'none';
    popupOverlay.style.display = 'none';
    bodyy.style.overflow = 'auto';
});